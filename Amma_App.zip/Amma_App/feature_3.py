from flask import Flask, render_template, request, jsonify, send_file
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired
import speech_recognition as sr
import pyttsx3
from pydub import AudioSegment
import os
import random
import cohere
from translate import Translator

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def generate_response(message):
   # Define the prompt for generating the response
   prompt = f"YOU ARE A CONVERSATIONAL AGENT THAT WILL SPEAK WITH ANYONE WHO STARTS A CONVERSATION WITH YOU. ASK THEM QUESTIONS AND KEEP THE CONVERSATION ENGAGING. THE USER SAYS {message}"
   # Call the Cohere generate endpoint
   response = co.generate(
       model='command',
       prompt=prompt,
       max_tokens=10000,
       temperature=0.7,
       k=0,
       p=0.75,
       stop_sequences=[],
       return_likelihoods='NONE'
   )
   # Print the generated recipe
   response = response.generations[0].text.strip()
   print("Generated Recipe:")
   print( response)
   return response


   # Generate the response




translator = Translator(from_lang="en", to_lang="ta")
# Initialize the Cohere client with your API key
co = cohere.Client('4Z2jCLMucsBO1oDz9K6ui8YDBMtso0QYJp4WUFTj')

app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'

# Set upload folder
UPLOAD_FOLDER = "static"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Ensure the folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)


# Flask-WTF form for chatbot input
class ChatForm(FlaskForm):
    user_input = StringField("Enter your message:", validators=[DataRequired()])
    submit = SubmitField("Send")


# Function to convert any audio to WAV format using FFmpeg
def convert_to_wav(input_path):
    """Convert audio to WAV using pydub and FFmpeg."""
    output_path = os.path.join(app.config["UPLOAD_FOLDER"], "input.wav")

    try:
        # Convert the file to WAV format
        audio = AudioSegment.from_file(input_path)
        audio.export(output_path, format="wav")
        return output_path
    except Exception as e:
        print(f"Error converting audio: {e}")
        return None


# Function to convert text to speech
def SpeakText(command):
    """Convert text to speech using pyttsx3."""
    engine = pyttsx3.init()
    audio_path = os.path.join(app.config["UPLOAD_FOLDER"], "response.mp3")
    engine.save_to_file(command, audio_path)
    engine.runAndWait()
    return audio_path


@app.route("/", methods=["GET", "POST"])
def index():
    """Render the main page with the chatbot interface."""
    form = ChatForm()

    if form.validate_on_submit():
        user_input = form.user_input.data

        # Generate chatbot response (replace this with AI/ML if needed)
        bot_response = f"I received your message: '{user_input}'"

        # Convert chatbot response to speech
        audio_path = SpeakText(bot_response)

        # Add a random value to prevent browser caching
        random_value = random.randint(1, 1000000)

        return render_template(
            "index.html",
            form=form,
            user_input=user_input,
            bot_response=bot_response,
            audio_path="/get_audio",
            random=random_value,  # Send a random value to bust cache
        )

    return render_template("index.html", form=form, user_input=None, bot_response=None, audio_path=None)


@app.route("/process_audio", methods=["POST"])
def process_audio():
    """Process audio and return text and audio."""
    # Initialize recognizer
    r = sr.Recognizer()

    # Get audio file from request
    audio_file = request.files["audio"]
    temp_path = os.path.join(app.config["UPLOAD_FOLDER"], audio_file.filename)
    audio_file.save(temp_path)

    # Convert audio to WAV if necessary
    audio_path = convert_to_wav(temp_path)

    if not audio_path:
        return jsonify({"error": "Failed to convert audio. Please upload a valid file."})

    # Process audio and convert to text
    with sr.AudioFile(audio_path) as source2:
        # Adjust for ambient noise
        r.adjust_for_ambient_noise(source2, duration=0.2)
        audio2 = r.listen(source2)

        try:
            # Recognize audio using Google API
            MyText = r.recognize_google(audio2)
            MyText = MyText.lower()

            message = MyText
            msg = generate_response(message)
            print("WAITINg")
            print(msg)

            # Generate chatbot response
            bot_response = f"I heard: '{msg}'"

            # Convert chatbot response to speech
            audio_path = SpeakText(bot_response)

            return jsonify({"text": bot_response, "audio_path": f"/get_audio?v={random.randint(1, 1000000)}"})
        except sr.RequestError:
            return jsonify({"error": "Could not request results; check your internet connection."})
        except sr.UnknownValueError:
            return jsonify({"error": "Sorry, I could not understand the audio."})


@app.route("/get_audio")
def get_audio():
    """Return the generated audio file."""
    return send_file("static/response.mp3", as_attachment=False)


if __name__ == "__main__":
    app.run(debug=True)