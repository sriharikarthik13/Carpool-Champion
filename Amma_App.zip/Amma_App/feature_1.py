import cohere
from translate import Translator
translator = Translator(from_lang="en", to_lang="ta")
# Initialize the Cohere client with your API key
co = cohere.Client('4Z2jCLMucsBO1oDz9K6ui8YDBMtso0QYJp4WUFTj')
def generate_response(message):
   # Define the prompt for generating the response
   prompt = f"Can you tell me some best possible responses to the following message and also explain what the message means: {message}"
   # Call the Cohere generate endpoint
   response = co.generate(
       model='command',
       prompt=prompt,
       max_tokens=10000,
       temperature=0.7,
       k=0,
       p=0.75,
       stop_sequences=[],
       return_likelihoods='NONE'
   )
   # Print the generated recipe
   response = response.generations[0].text.strip()
   print("Generated Recipe:")
   print( response)


   # Generate the response
message = "When can you send the packet"

translated_text = translator.translate(message)
print("Tamil Translation is :", translated_text)


generate_response(message)

