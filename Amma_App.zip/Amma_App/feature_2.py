import cohere
from translate import Translator

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

translator = Translator(from_lang="en", to_lang="ta")
# Initialize the Cohere client with your API key
co = cohere.Client('4Z2jCLMucsBO1oDz9K6ui8YDBMtso0QYJp4WUFTj')
def generate_response(message):
   # Define the prompt for generating the response
   prompt = f"Can you generate a VERY BASIC SIMPLE AND SMALL one line sentence based on the following topic: {message}. REMEMBER TO GIVE ONLY THE SENTENCE NO ADDITIONAL TEXT"
   # Call the Cohere generate endpoint
   response = co.generate(
       model='command',
       prompt=prompt,
       max_tokens=10000,
       temperature=0.7,
       k=0,
       p=0.75,
       stop_sequences=[],
       return_likelihoods='NONE'
   )
   # Print the generated recipe
   response = response.generations[0].text.strip()
   print("Generated Recipe:")
   print( response)
   return response


   # Generate the response
message = "Apples"




cd = generate_response(message)

translated_text = translator.translate(cd)
print("Tamil Translation is :", translated_text)



# Input texts
text1 = cd



text2 = input("enyer:")

# Convert texts to TF-IDF vectors
vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform([text1, text2])

# Calculate cosine similarity
similarity_score = cosine_similarity(tfidf_matrix[0], tfidf_matrix[1])

print(f"Cosine Similarity: {similarity_score[0][0]:.4f}")

score = similarity_score[0][0] * 100

if score >= 40:
   print("HERO")
else:
   print("LEARNER")