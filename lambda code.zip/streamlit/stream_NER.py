import streamlit as st
import datetime
import requests

lambda_url = "https://dgbvl4r65nuto2e7flibljws4e0lshhn.lambda-url.us-east-1.on.aws/"

st.title("Chatbot with History")

if "chats" not in st.session_state:
    st.session_state.chats = {}  
if "current_chat" not in st.session_state:
    st.session_state.current_chat = None  

st.sidebar.title("Entity Extraction Agent")

st.sidebar.markdown(
    """
    <style>
        div.stButton > button {
            background-color: #4CAF50 !important; /* Green color */
            color: white !important;
            font-weight: bold;
            border-radius: 8px;
            width: 100%;
        }
    </style>
    """,
    unsafe_allow_html=True,
)

# Button to create a new chat
if st.sidebar.button("New Chat"):
    chat_id = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") 
    st.session_state.chats[chat_id] = [] 
    st.session_state.current_chat = chat_id 

# List existing chats
for chat_id in st.session_state.chats.keys():
    if st.sidebar.button(chat_id, key=chat_id):
        st.session_state.current_chat = chat_id 

# Display a list of values below the chat area

if st.session_state.current_chat is None:
    st.sidebar.write("Start a new chat or select an existing one.")
else:
    chat_history = st.session_state.chats[st.session_state.current_chat]

    # Display chat history
    for message in chat_history:
        with st.chat_message("user" if message["user"] == "user" else "assistant"):
            st.write(message["text"])

    # Get user input
    user_input = st.chat_input("Type your message...")

    if user_input:
        chat_history.append({"user": "user", "text": user_input})

        with st.chat_message("user"):
            st.write(user_input)

        # Send request to Lambda function
        payload = {"inputText": user_input}
        response = requests.post(lambda_url, json=payload)
        val = response.json()
        x = val.get("final_answer")

        chatbot_response = f"{x}"

        chat_history.append({"user": "chatbot", "text": chatbot_response})

        with st.chat_message("assistant"):
            st.write(chatbot_response)

        st.session_state.chats[st.session_state.current_chat] = chat_history

st.sidebar.markdown("### Important Values")
important_values = ["Value 1", "Value 2", "Value 3", "Value 4", "Value 5"]
for val in important_values:
    st.sidebar.write(f"- {val}")







