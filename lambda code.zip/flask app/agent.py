from flask import Flask, request, jsonify, render_template, session,redirect,url_for
from flask_wtf import FlaskForm
from wtforms import StringField,SubmitField
import requests
import boto3
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret'
lambda_url = "https://kcfssbo5kogjc7uqhgu4qci6ja0tmbpz.lambda-url.us-east-1.on.aws/"


class inputForm(FlaskForm):
     userinput = StringField("What do you want to ask me?")
     submit = SubmitField("submit")

@app.route('/refresh',methods=['GET','POST'])
def hme():
    session.clear()
    return redirect(url_for('send_request'))


@app.route('/trans')
def trans():
    pass



def chatbot(user_input):
    payload = {"inputText": user_input}
    response = requests.post(lambda_url,json=payload)
    if response.status_code == 200:
        val= response.json()
        chatvalue = val.get('final_answer','NO DATA AVAILABLE')
        filevalue = val.get('file_answer','')

    else:
        chatvalue = f"Error in Response. Please rephrase your query!"
        filevalue = ''
    return chatvalue,filevalue






@app.route('/', methods=['POST','GET'])
def send_request():
   form = inputForm()
   response_val = ""
   html_content = ''
   display_button =False
   fval = ''
   if 'chat_history' not in session:
    session['chat_history'] = []
   if form.validate_on_submit():

    
    query = form.userinput.data
  
    if query.lower() != 'exit':
        val,fval = chatbot(query)
        response_val = val
        print(f'Response val is {response_val}')
        if len(fval) >= 1:
            display_button = True
            S3_BUCKET = 'adashok-darzalex-csv-jc'
            S3_KEY = 'output_0.html'
            s3_client = boto3.client('s3')
            html_file = s3_client.get_object(Bucket=S3_BUCKET, Key = S3_KEY)
            html_content = html_file['Body'].read().decode('utf-8')
        else:
            display_button = False
            html_content = ''
    session['chat_history'].append({'sender':'user' , 'message' : query})
    session['chat_history'].append({'sender':'bot' , 'message' : response_val})

    session.modified = True
    form.userinput.data = ""


  # print(f' SESSION IS {session['chat_history']}')
  # print(f'fval is {fval}')
  # print(f'display_button is {display_button}')

   if display_button:
            html_content = html_content
   else:
            html_content = 'NO PLOT FOR CURRENT QUERY'
   return render_template('clinical_agent.html',form=form,chat_history = session['chat_history'],html_content=html_content,display_button=display_button)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)