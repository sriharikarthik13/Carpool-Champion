from tkinter.tix import Tree
from flask import Flask, redirect, request, jsonify, render_template, session, url_for,json
from flask_wtf import FlaskForm
import pandas as pd
from wtforms import StringField,SubmitField
import requests
import boto3
import os
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret'
lambda_url = "https://kcfssbo5kogjc7uqhgu4qci6ja0tmbpz.lambda-url.us-east-1.on.aws/"
lambda_url_1 = "https://vg2ifiizcd6fisys57eaq2g7zi0ftgqh.lambda-url.us-east-1.on.aws/"



class inputForm(FlaskForm):
     userinput = StringField("What do you want to ask me?")
     submit = SubmitField("submit")

@app.route('/')
def hme():
        session.clear()
        return render_template('home.html')


@app.route('/transcribes', methods=['POST','GET'])
def trans1():
    if request.method == 'GET':
        return "OK"
    file = request.files["audio"]
    file_path = os.path.join("audio4.wav")
    file.save(file_path)
    #session["voice"] = "OK VOICE IS READY"

    return jsonify({'transcription' : 'OK THANKS' })


@app.route('/transcribe', methods=['POST','GET'])
def trans():
        
        data = request.get_json()
        #audio_file_path = audio_file['feedbacklist',[]]
        print(data)
        print(data['feedbacklist'])

        data = data['feedbacklist'][0]

        payload = {'data' : data}
        response = requests.post(lambda_url_1, json = payload)

        val = response.json()
        print(val)

        #df2 = pd.json_normalize(data)

        #df = pd.read_csv('feedback.csv')
        #df2["Id"] = len(df)
        #final_df = pd.concat([df,df2], ignore_index=True)

        #final_df.to_csv("feedback.csv", index=False)

        return jsonify({'message' : 'OK THANKS' })


@app.route('/transview', methods=['POST','GET'])
def transview():
        return render_template('trans.html')


def chatbot(user_input):
    payload = {"inputText": user_input}
    response = requests.post(lambda_url,json=payload)
    if response.status_code == 200:
        val= response.json()
        chatvalue = val.get('final_answer','NO DATA AVAILABLE')
        filevalue = val.get('file_answer','')
       
    else:
        chatvalue = f"Error in Response. Please rephrase your query!"
        filevalue = ''
    return chatvalue,filevalue


@app.route('/refresh', methods=['POST','GET'])
def send_request_refresh():
    session.clear()
    return redirect(url_for('send_request'))




@app.route('/send_request', methods=['POST','GET'])
def send_request():
   form = inputForm()
   response_val = ""
   query = 'Enter Your first query'
   html_content = 'fdfdf'
   display_button = False
   vflag = False



   if request.method == "POST" and "audio" in request.files:
       file = request.files["audio"]
       file_path = os.path.join("audiomain.wav")
       file.save(file_path)
       vflag = True
       print("SDSADAS")
       form = inputForm()
       query = "OK BRO "
       response_val = "EJJJ"

       if 'chat_history' not in session:
            session['chat_history'] = []

      
    

       session['chat_history'].append({'sender':'user' , 'message' : query})
       print(session['chat_history'])
       session['chat_history'].append({'sender':'bot' , 'message' : response_val})
       print("HIHOISAHDOSAOIDHASODHOASIHDOI")
       print(session['chat_history'])

       
       form.userinput.data = ""

       return "HELLO"


   else:

    if 'chat_history' not in session:
        session['chat_history'] = []

       
        
    
    if form.validate_on_submit():

        if vflag:
            query = "GREAT THANKS"
        else:
            query = form.userinput.data


        if query.lower() != 'exit':
            #val,fval = chatbot(query)
            val = "HELLO YOUR RESPONSE IS RECORDED THANKS"
            response_val = val
            fval = None
            #print(len(fval))
            if query == 'NO':
                fval = None
            
            print(f'Response val is {response_val}')
            if fval is not None:
                display_button = True
                #S3_BUCKET = 'text-to-sql-ak'
                #S3_KEY = 'output.html'
                #s3_client = boto3.client('s3')
                #html_file = s3_client.get_object(Bucket=S3_BUCKET, Key = S3_KEY)
                #html_content = html_file['Body'].read().decode('utf-8')
                print(html_content)
            else:
                display_button = False

        session['chat_history'].append({'sender':'user' , 'message' : query})
        session['chat_history'].append({'sender':'bot' , 'message' : response_val})

        session.modified = True
        form.userinput.data = ""

    print(f' SESSION IS {session['chat_history']}')
    if display_button:
            
            html_content = '''<html>HI HELLO BOR <br>  HI HELLO BOR <br> HI HELLO BOR <br> HI HELLO BOR <br>HI HELLO BOR <br> HI HELLO BOR <br> HI HELLO BOR <br> HI HELLO BOR <br> <br> HI HELLO BOR <br> <br> HI HELLO BOR <br> <br> HI HELLO BOR <br> <br> HI HELLO BOR <br> <br> HI HELLO BOR <br> <br> HI HELLO BOR <br> <br> HI HELLO BOR <br> <br> HI HELLO BOR <br>/html>'''
    else:
        html_content = '''NO PLOT TO DISPLAY'''

    print(f'QUERY IS {query}') 
    return render_template('com_test1.html',form=form,chat_history = session['chat_history'],html_content=html_content,display_button=display_button,query=query) 

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
    

