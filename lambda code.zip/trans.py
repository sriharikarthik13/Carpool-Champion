import sounddevice as sd

from scipy.io.wavfile import write

def record(filename, duration = 10, samplerate = 44100):
    print("RECORDING STARTED")
    audio = sd.rec(int(duration*samplerate), samplerate=samplerate, channels=1, dtype='int16') 
    sd.wait()
    print("RECORDING DONE")


    write(filename,samplerate,audio)
    print("SAVED")


record('text.mp3')