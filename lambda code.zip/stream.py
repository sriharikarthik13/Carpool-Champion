import streamlit as st
import datetime
import requests
import boto3

# AWS S3 bucket information
bucket = 'ner-relationship'
s3 = boto3.client('s3')

# Lambda endpoint
lambda_url = "https://dgbvl4r65nuto2e7flibljws4e0lshhn.lambda-url.us-east-1.on.aws/"

list_a = ["Item 1", "Item 2", "Item 3", "Item 4", "Item 5"]  # Items for dropdown list

# Ensure that the session state variables are initialized
if "chats" not in st.session_state:
    st.session_state.chats = {}

if "current_chat" not in st.session_state:
    st.session_state.current_chat = None

if "show_description" not in st.session_state:
    st.session_state.show_description = True  # Show description initially

# Apply custom CSS for a more elegant and modern look
st.markdown(
    """
    <style>
    /* Main container */
    .main {
        background-color: #f5f7fa;
    }

    /* Sidebar design */
    [data-testid="stSidebar"] {
        background-color: #1f2937;
        color: white;
        padding-top: 20px;
    }

    /* Sidebar title */
    .sidebar-title {
        font-size: 24px;
        font-weight: bold;
        color: #fff;
        margin-bottom: 20px;
        text-align: center;
    }

    /* Centered and slightly higher description with image */
    .description-container {
        background-color: #ffffff;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
        width: 50%;
        margin: 0 auto 20px auto; /* Move even higher */
        text-align: center;
        border-left: 5px solid #4CAF50;
        position: relative;
        top: -100px; /* Move the description further up */
    }

    /* Description image */
    .description-image {
        width: 100px;
        margin-bottom: 10px;
    }

    /* Button styles */
    div.stButton > button {
        background-color: #4CAF50 !important;
        color: white !important;
        font-weight: bold;
        border-radius: 8px;
        width: 100%;
        padding: 10px;
        transition: 0.3s;
    }
    div.stButton > button:hover {
        background-color: #45a049 !important;
    }

    /* Chat container */
    .chat-container {
        background-color: #ffffff;
        border-radius: 12px;
        padding: 15px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin-top: 10px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Sidebar layout with image and title
with st.sidebar:
    st.image("Ham.png", width=180)  # Update the path if required
    st.markdown('<div class="sidebar-title">Entity Extraction Agent</div>', unsafe_allow_html=True)

    # Button to start a new chat
    if st.button("New Chat"):
        chat_id = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        st.session_state.chats[chat_id] = []
        st.session_state.current_chat = chat_id
        st.session_state.show_description = False  # Hide description after starting chat

    # Display list of items below New Chat
    st.markdown("### 📋 Available Items:")
    for item in list_a:
        st.markdown(f"- {item}")

    # Button to show description again (visible after new chat is started)
    if not st.session_state.show_description and st.session_state.current_chat is not None:
        if st.button("Show Description"):
            st.session_state.show_description = True

    # Display previous chats as buttons
    for chat_id in st.session_state.chats.keys():
        if st.button(chat_id, key=chat_id):
            st.session_state.current_chat = chat_id
            st.session_state.show_description = False

    if st.session_state.current_chat is None:
        st.write("Start a new chat or select an existing one.")

# Show description only on the initial page or when 'Show Description' is clicked
if st.session_state.show_description:
    st.markdown(
        """
        <div class="description-container">
            <img src="https://cdn-icons-png.flaticon.com/512/103/103116.png" class="description-image"/>
            <h2>Welcome to Entity Extraction Agent</h2>
            <p style="font-size: 16px; line-height: 1.6;">
                The **Entity Extraction Agent** is a state-of-the-art NLP solution designed to 
                analyze unstructured text and extract key entities. Leveraging advanced AI models, 
                it helps in identifying relationships between entities and transforming raw data into 
                structured insights. This enhances downstream applications by improving decision-making.
            </p>
            <p style="font-size: 16px; line-height: 1.6;">
                Get started by clicking on <strong>New Chat</strong> to initiate a conversation and explore
                the capabilities of the agent.
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

# Main chat window logic (only shown after a new chat is started)
if st.session_state.current_chat is not None and not st.session_state.show_description:
    chat_history = st.session_state.chats[st.session_state.current_chat]

    # Only show chat if history exists
    if chat_history:
        for message in chat_history:
            with st.chat_message("user" if message["user"] == "user" else "assistant"):
                st.write(message["text"])

    # User input and response
    user_input = st.chat_input("Type your message...")

    if user_input:
        chat_history.append({"user": "user", "text": user_input})

        with st.chat_message("user"):
            st.write(user_input)

        # Sending user input to Lambda
        payload = {"inputText": user_input}
        response = requests.post(lambda_url, json=payload)

        val = response.json()
        x = val.get("final_answer")

        # Chatbot response
        bot_response = f"{x}"
        chat_history.append({"user": "chatbot", "text": bot_response})

        with st.chat_message("assistant"):
            st.write(bot_response)

        # Update chat history
        st.session_state.chats[st.session_state.current_chat] = chat_history